# Keycloak Theme

A custom theme for Keycloak Login Page

![theme](./screenshot.png?raw=true "Demo Theme")

### How to run

```shell script
docker-compose up -d
```
